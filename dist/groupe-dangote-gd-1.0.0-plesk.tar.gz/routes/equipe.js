const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { requireAuth } = require('../middleware/auth');

async function getFilleulsByLevel(user_id, level) {
  let current = [user_id];
  for (let i = 1; i <= level; i++) {
    if (!current.length) return [];
    const placeholders = current.map(() => '?').join(',');
    const [rows] = await db.query(`SELECT id FROM utilisateurs WHERE parrain_id IN (${placeholders})`, current);
    current = rows.map(r => r.id);
    if (i === level) return current;
  }
  return [];
}

async function getDepotsValides(ids) {
  if (!ids.length) return 0;
  const placeholders = ids.map(() => '?').join(',');
  const [[row]] = await db.query(
    `SELECT COALESCE(SUM(montant), 0) as total FROM depots WHERE user_id IN (${placeholders}) AND statut = 'valide'`,
    ids
  );
  return parseFloat(row.total || 0);
}

router.get('/equipe', requireAuth, async (req, res) => {
  const user_id = req.session.user_id;
  try {
    const [[user]] = await db.query('SELECT * FROM utilisateurs WHERE id = ?', [user_id]);

    const [f1, f2, f3] = await Promise.all([
      getFilleulsByLevel(user_id, 1),
      getFilleulsByLevel(user_id, 2),
      getFilleulsByLevel(user_id, 3),
    ]);

    const [depot1, depot2, depot3] = await Promise.all([
      getDepotsValides(f1),
      getDepotsValides(f2),
      getDepotsValides(f3),
    ]);

    // Helper to fetch details for any level
    async function fetchDetails(ids) {
      if (!ids.length) return [];
      const placeholders = ids.map(() => '?').join(',');
      const [rows] = await db.query(
        `SELECT u.id, u.nom, u.telephone, u.pays, u.date_inscription,
         (SELECT COUNT(*) FROM commandes c WHERE c.user_id = u.id AND c.statut = 'actif' AND c.date_fin >= CURRENT_DATE) as has_active
         FROM utilisateurs u
         WHERE u.id IN (${placeholders}) ORDER BY u.date_inscription DESC`,
        ids
      );
      return rows;
    }

    const [filleuls_details1, filleuls_details2, filleuls_details3] = await Promise.all([
      fetchDetails(f1),
      fetchDetails(f2),
      fetchDetails(f3),
    ]);

    const [[vip]] = await db.query('SELECT * FROM vip WHERE user_id = ?', [user_id]);

    // Prefer the published production domain (REPLIT_DOMAINS) so referral
    // links work for external visitors. REPLIT_DEV_DOMAIN is a temporary
    // workspace preview URL not meant to be shared with end users.
    const baseUrl = process.env.REPLIT_DOMAINS
      ? `https://${process.env.REPLIT_DOMAINS.split(',')[0]}`
      : process.env.REPLIT_DEV_DOMAIN
        ? `https://${process.env.REPLIT_DEV_DOMAIN}`
        : `${req.protocol}://${req.get('host')}`;

    res.render('equipe', {
      user,
      filleuls_niveau1: f1, filleuls_niveau2: f2, filleuls_niveau3: f3,
      depot_niveau1: depot1, depot_niveau2: depot2, depot_niveau3: depot3,
      filleuls_details1, filleuls_details2, filleuls_details3,
      vip: vip || { niveau: 0, invitations_actuelles: 0, invitations_requises: 3 },
      baseUrl,
    });
  } catch (e) {
    console.error(e);
    res.redirect('/');
  }
});

// AJAX endpoint for filleuls list
router.get('/get_filleuls', requireAuth, async (req, res) => {
  const user_id = req.session.user_id;
  const level = parseInt(req.query.level) || 1;
  try {
    const ids = await getFilleulsByLevel(user_id, level);
    if (!ids.length) return res.json({ filleuls: [] });
    const placeholders = ids.map(() => '?').join(',');
    const [filleuls] = await db.query(
      `SELECT u.id, u.nom, u.telephone, u.pays, s.solde FROM utilisateurs u LEFT JOIN soldes s ON u.id = s.user_id WHERE u.id IN (${placeholders})`,
      ids
    );
    res.json({ filleuls });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
