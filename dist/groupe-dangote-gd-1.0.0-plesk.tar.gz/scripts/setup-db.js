#!/usr/bin/env node
/**
 * Database setup script — creates all tables and seeds investment plans.
 * Run once after cloning: npm run setup-db
 * Safe to re-run: all statements are idempotent.
 */

const { Pool } = require('pg');

const connectionString = process.env.SUPABASE_DATABASE_URL || process.env.DATABASE_URL;
const isSupabase = !!process.env.SUPABASE_DATABASE_URL;

if (!connectionString) {
  console.error('Error: SUPABASE_DATABASE_URL or DATABASE_URL environment variable is not set.');
  process.exit(1);
}

const pool = new Pool({
  connectionString,
  ssl: isSupabase || process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
});

const SCHEMA = `
CREATE TABLE IF NOT EXISTS utilisateurs (
  id SERIAL PRIMARY KEY,
  nom VARCHAR(255) NOT NULL,
  pays VARCHAR(100),
  telephone VARCHAR(50) UNIQUE NOT NULL,
  mot_de_passe VARCHAR(255) NOT NULL,
  parrain_id INTEGER REFERENCES utilisateurs(id),
  code_parrainage VARCHAR(50) UNIQUE,
  date_inscription TIMESTAMP DEFAULT NOW(),
  last_spin_time TIMESTAMP,
  is_admin BOOLEAN DEFAULT false,
  is_banned BOOLEAN DEFAULT false,
  retrait_bloque BOOLEAN DEFAULT false
);

CREATE TABLE IF NOT EXISTS soldes (
  id SERIAL PRIMARY KEY,
  user_id INTEGER UNIQUE REFERENCES utilisateurs(id),
  solde NUMERIC(15,2) DEFAULT 0,
  solde_precedent NUMERIC(15,2) DEFAULT 0
);

CREATE TABLE IF NOT EXISTS vip (
  id SERIAL PRIMARY KEY,
  user_id INTEGER UNIQUE REFERENCES utilisateurs(id),
  niveau INTEGER DEFAULT 0,
  pourcentage NUMERIC(5,2) DEFAULT 0,
  invitations_requises INTEGER DEFAULT 0,
  invitations_actuelles INTEGER DEFAULT 0
);

-- rendement_journalier is the daily yield rate as a percentage (e.g. 1.72).
-- The app computes gain_journalier = prix * rendement_journalier / 100 at runtime.
CREATE TABLE IF NOT EXISTS planinvestissement (
  id SERIAL PRIMARY KEY,
  nom VARCHAR(255) UNIQUE NOT NULL,
  prix NUMERIC(15,2),
  duree_jours INTEGER,
  rendement_journalier NUMERIC(8,4),
  image_url VARCHAR(500),
  description TEXT,
  bloque BOOLEAN DEFAULT FALSE,
  prix_action NUMERIC(15,2),
  actions_minimum INTEGER DEFAULT 1,
  strategie_json TEXT
);

CREATE TABLE IF NOT EXISTS commandes (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES utilisateurs(id),
  plan_id INTEGER REFERENCES planinvestissement(id),
  montant NUMERIC(15,2),
  gain_journalier NUMERIC(15,2),
  nombre_actions NUMERIC(15,4) DEFAULT 1,
  date_debut TIMESTAMP DEFAULT NOW(),
  date_fin TIMESTAMP,
  date_creation TIMESTAMP DEFAULT NOW(),
  statut VARCHAR(50) DEFAULT 'actif'
);

CREATE TABLE IF NOT EXISTS depots (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES utilisateurs(id),
  montant NUMERIC(15,2),
  methode VARCHAR(100),
  numero_transaction VARCHAR(255),
  pays VARCHAR(100),
  fournisseur VARCHAR(50) DEFAULT 'ashtechpay',
  provider_transaction_id VARCHAR(255),
  provider_service_id INTEGER,
  statut VARCHAR(50) DEFAULT 'en_attente',
  date_depot TIMESTAMP DEFAULT NOW(),
  date_validation TIMESTAMP
);

CREATE TABLE IF NOT EXISTS retraits (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES utilisateurs(id),
  montant NUMERIC(15,2),
  montant_net NUMERIC(15,2),
  frais NUMERIC(15,2) DEFAULT 0,
  operateur VARCHAR(100),
  pays VARCHAR(100),
  methode VARCHAR(100),
  numero_compte VARCHAR(255),
  fournisseur VARCHAR(50) DEFAULT 'manuel',
  provider_service_id INTEGER,
  provider_transaction_id VARCHAR(255),
  provider_order_id VARCHAR(255),
  statut VARCHAR(50) DEFAULT 'en_attente',
  date_demande TIMESTAMP DEFAULT NOW(),
  date_traitement TIMESTAMP
);

-- commande_id links a revenue entry to a specific investment order.
-- date_paiement records when the daily yield was credited.
CREATE TABLE IF NOT EXISTS historique_revenus (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES utilisateurs(id),
  commande_id INTEGER REFERENCES commandes(id),
  montant NUMERIC(15,2),
  type VARCHAR(100),
  date_paiement TIMESTAMP DEFAULT NOW(),
  date_creation TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS posts (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES utilisateurs(id),
  message TEXT,
  image VARCHAR(255),
  statut VARCHAR(50) DEFAULT 'en_attente',
  date_creation TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS codes_utilises (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES utilisateurs(id),
  code VARCHAR(100),
  montant NUMERIC(15,2),
  date_utilisation TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS filleuls (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES utilisateurs(id),
  filleul_id INTEGER REFERENCES utilisateurs(id),
  niveau INTEGER DEFAULT 1,
  date_inscription TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS connexions_journalieres (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES utilisateurs(id),
  date_connexion DATE DEFAULT CURRENT_DATE
);

CREATE TABLE IF NOT EXISTS pieces (
  id SERIAL PRIMARY KEY,
  user_id INTEGER UNIQUE REFERENCES utilisateurs(id),
  solde NUMERIC(15,2) DEFAULT 0,
  solde_precedent NUMERIC(15,2) DEFAULT 0
);

CREATE TABLE IF NOT EXISTS app_parametres (
  cle VARCHAR(100) PRIMARY KEY,
  valeur TEXT
);

-- Persistent express-session storage for external deployments.
CREATE TABLE IF NOT EXISTS user_sessions (
  sid VARCHAR(255) PRIMARY KEY,
  sess JSON NOT NULL,
  expire TIMESTAMP(6) NOT NULL
);

CREATE INDEX IF NOT EXISTS user_sessions_expire_idx ON user_sessions (expire);

CREATE TABLE IF NOT EXISTS vip_paliers (
  id SERIAL PRIMARY KEY,
  niveau INTEGER UNIQUE NOT NULL,
  label VARCHAR(255),
  filleuls_requis INTEGER DEFAULT 0,
  montant_cadeau NUMERIC(15,2) DEFAULT 0
);

-- Gift codes created and managed by the admin (replaces the old hardcoded
-- validCodes object in routes/cadeau.js). places_utilisees is incremented
-- atomically each time a user redeems the code; the code stops working once
-- places_utilisees reaches places_disponibles or date_expiration has passed.
CREATE TABLE IF NOT EXISTS codes_cadeaux (
  id SERIAL PRIMARY KEY,
  code VARCHAR(100) UNIQUE NOT NULL,
  montant NUMERIC(15,2) NOT NULL,
  regles_json TEXT,
  places_disponibles INTEGER NOT NULL DEFAULT 1,
  places_utilisees INTEGER NOT NULL DEFAULT 0,
  date_expiration TIMESTAMP,
  actif BOOLEAN DEFAULT true,
  date_creation TIMESTAMP DEFAULT NOW()
);
`;

// rendement_journalier values computed from original absolute gains:
//   gain_journalier = prix * rendement_journalier / 100
// e.g. VIP 1: 1000 * 1.6 / 100 = 16 FCFA/day
const SEED_PLANS = `
INSERT INTO planinvestissement (nom, prix, duree_jours, rendement_journalier, image_url, description)
VALUES
  ('Action VIP 1',        1000,    125, 1.60,  NULL, 'Plan d''entrée — 1 000 FCFA')
ON CONFLICT (nom) DO NOTHING;
`;

// New market plans use a variable number of shares. `prix` remains the
// minimum investment for compatibility with the existing admin/dashboard
// views; the purchase route uses prix_action and strategie_json.
const SEED_MARKET_PLANS = `
INSERT INTO planinvestissement
  (nom, prix, duree_jours, rendement_journalier, image_url, description,
   prix_action, actions_minimum, strategie_json)
VALUES
  ('Dangote Refinery — IPO', 2250, 125, 5, '/images/dashboard-hero-1.jpeg',
   '1 action = 225 FCFA — minimum 10 actions',
   225, 10, '[{"min":0,"max":6000,"rate":5},{"min":6001,"max":15000,"rate":7},{"min":15001,"max":40000,"rate":10},{"min":40001,"max":170000,"rate":15},{"min":170001,"max":10000000,"rate":20},{"min":10000001,"max":null,"rate":20}]'),
  ('Dangote Cement — DANGCEM', 4500, 125, 5, '/images/dashboard-hero-3.jpeg',
   '1 action = 450 FCFA — minimum 50 actions',
   450, 50, '[{"min":0,"max":6000,"rate":5},{"min":6001,"max":15000,"rate":7},{"min":15001,"max":40000,"rate":10},{"min":40001,"max":170000,"rate":15},{"min":170001,"max":10000000,"rate":20},{"min":10000001,"max":null,"rate":20}]'),
  ('Dangote Sugar — DANGSUGAR', 60000, 125, 5, '/images/dashboard-hero-5.jpeg',
    '1 action = 30 FCFA — minimum 2 000 actions',
    30, 2000, '[{"min":0,"max":6000,"rate":5},{"min":6001,"max":15000,"rate":7},{"min":15001,"max":40000,"rate":10},{"min":40001,"max":170000,"rate":15},{"min":170001,"max":10000000,"rate":20},{"min":10000001,"max":null,"rate":20}]')
ON CONFLICT (nom) DO NOTHING;
`;

async function setup() {
  const client = await pool.connect();
  try {
    console.log('Creating tables…');
    await client.query(SCHEMA);
    // Add columns that may be missing from older installs (idempotent)
    const alterations = [
      `ALTER TABLE utilisateurs ADD COLUMN IF NOT EXISTS is_banned BOOLEAN DEFAULT false`,
      `ALTER TABLE utilisateurs ADD COLUMN IF NOT EXISTS retrait_bloque BOOLEAN DEFAULT false`,
      `ALTER TABLE planinvestissement ADD COLUMN IF NOT EXISTS bloque BOOLEAN DEFAULT false`,
      `ALTER TABLE planinvestissement ADD COLUMN IF NOT EXISTS prix_action NUMERIC(15,2)`,
      `ALTER TABLE planinvestissement ADD COLUMN IF NOT EXISTS actions_minimum INTEGER DEFAULT 1`,
      `ALTER TABLE planinvestissement ADD COLUMN IF NOT EXISTS strategie_json TEXT`,
      `ALTER TABLE codes_cadeaux ADD COLUMN IF NOT EXISTS regles_json TEXT`,
      `ALTER TABLE commandes ADD COLUMN IF NOT EXISTS nombre_actions NUMERIC(15,4) DEFAULT 1`,
      `ALTER TABLE commandes ALTER COLUMN nombre_actions TYPE NUMERIC(15,4) USING nombre_actions::numeric`,
      `ALTER TABLE historique_revenus ADD COLUMN IF NOT EXISTS niveau INTEGER`,
      `ALTER TABLE historique_revenus ADD COLUMN IF NOT EXISTS source VARCHAR(100)`,
      `ALTER TABLE retraits ADD COLUMN IF NOT EXISTS montant_net NUMERIC(15,2)`,
      `ALTER TABLE retraits ADD COLUMN IF NOT EXISTS frais NUMERIC(15,2) DEFAULT 0`,
      `ALTER TABLE retraits ADD COLUMN IF NOT EXISTS operateur VARCHAR(100)`,
      `ALTER TABLE retraits ADD COLUMN IF NOT EXISTS pays VARCHAR(100)`,
      `ALTER TABLE retraits ADD COLUMN IF NOT EXISTS fournisseur VARCHAR(50) DEFAULT 'manuel'`,
      `ALTER TABLE retraits ADD COLUMN IF NOT EXISTS provider_service_id INTEGER`,
      `ALTER TABLE retraits ADD COLUMN IF NOT EXISTS provider_transaction_id VARCHAR(255)`,
      `ALTER TABLE retraits ADD COLUMN IF NOT EXISTS provider_order_id VARCHAR(255)`,
      `CREATE UNIQUE INDEX IF NOT EXISTS historique_revenus_salaire_niveau_uidx ON historique_revenus(user_id, niveau) WHERE type='salaire'`,
      `CREATE UNIQUE INDEX IF NOT EXISTS codes_utilises_user_code_uidx ON codes_utilises (user_id, code)`,
    ];
    for (const sql of alterations) await client.query(sql);
    console.log('✓ Schema ready (18 tables)');

    console.log('Seeding investment plans…');
    const res = await client.query(SEED_PLANS);
    const marketRes = await client.query(SEED_MARKET_PLANS);
    await client.query(`
      UPDATE planinvestissement
      SET prix = CASE nom
        WHEN 'Dangote Refinery — IPO' THEN 2250
        WHEN 'Dangote Cement — DANGCEM' THEN 22500
        WHEN 'Dangote Sugar — DANGSUGAR' THEN 60000
        WHEN 'NASCON' THEN 345000
      END,
      actions_minimum = CASE nom
        WHEN 'Dangote Refinery — IPO' THEN 10
        WHEN 'Dangote Cement — DANGCEM' THEN 50
        WHEN 'Dangote Sugar — DANGSUGAR' THEN 2000
        WHEN 'NASCON' THEN 5000
      END,
      description = CASE nom
        WHEN 'Dangote Refinery — IPO' THEN '1 action = 225 FCFA — minimum 10 actions'
        WHEN 'Dangote Cement — DANGCEM' THEN '1 action = 450 FCFA — minimum 50 actions'
        WHEN 'Dangote Sugar — DANGSUGAR' THEN '1 action = 30 FCFA — minimum 2 000 actions'
        WHEN 'NASCON' THEN '1 action = 69 FCFA — minimum 5 000 actions'
      END
      WHERE nom IN (
        'Dangote Refinery — IPO',
        'Dangote Cement — DANGCEM',
        'Dangote Sugar — DANGSUGAR',
        'NASCON'
      )
    `);
    console.log(`✓ Plans seeded (${res.rowCount + marketRes.rowCount} inserted)`);

    console.log('\nDatabase setup complete. Run `node server.js` to start the app.');
  } catch (err) {
    console.error('Setup failed:', err.message);
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
}

setup();
